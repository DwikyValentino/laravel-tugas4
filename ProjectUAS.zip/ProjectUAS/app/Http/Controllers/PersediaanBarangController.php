<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PersediaanBarangController extends Controller
{
    public function index()
    {
    	// mengambil data dari table persediaanbarang
    	$persediaanbarang = DB::table('persediaanbarang')->get();
 
    	// mengirim data persediaan ke view index
    	return view('index',['persediaanbarang' => $persediaanbarang]);
	}
	
	// method untuk menampilkan view form tambah persediaanbarang
	public function tambah()
	{
 		// memanggil view tambah
		return view('tambah');
	}

	// method untuk insert data ke table persediaanbarang
	public function store(Request $request)
	{
		// insert data ke table persediaanbarang
		DB::table('persediaanbarang')->insert([
			'kodebarang' => $request->kodebarang,
			'namabarang' => $request->namabarang,
			'hargapokok' => $request->hargapokok,
			'hargajualsatuan' => $request->hargajualsatuan,
			'jumlah' => $request->jumlah,
			'nilai' => $request->nilai
		]);

		// alihkan halaman ke halaman persediaanbarang
		return redirect('/persediaanbarang');
		
	}

	// method untuk edit data persediaanbarang
	public function edit($id_barang)
	{
		// mengambil data persediaanbarang berdasarkan id yang dipilih
		$persediaanbarang = DB::table('persediaanbarang')->where('id_barang',$id_barang)->get();

		// passing data persediaanbarang yang didapat ke view edit.blade.php
		return view('edit',['persediaanbarang' => $persediaanbarang]);
 
	}

	// update data persediaanbarang
	public function update(Request $request)
	{
		// update data persediaanbarang
		DB::table('persediaanbarang')->where('id_barang',$request->id_barang)->update([
			'kodebarang' => $request->kodebarang,
			'namabarang' => $request->namabarang,
			'hargapokok' => $request->hargapokok,
			'hargajualsatuan' => $request->hargajualsatuan,
			'jumlah' => $request->jumlah,
			'nilai' => $request->nilai
	]);

	// alihkan halaman ke halaman persediaanbarang
	return redirect('/persediaanbarang');
	}

	// method untuk hapus data persediaanbarang
	public function hapus($id_barang)
	{
		// menghapus data persediaanbarang berdasarkan id yang dipilih
		DB::table('persediaanbarang')->where('id_barang',$id_barang)->delete();
		
		// alihkan halaman ke halaman persediaanbarang
		return redirect('/persediaanbarang');
	}
}