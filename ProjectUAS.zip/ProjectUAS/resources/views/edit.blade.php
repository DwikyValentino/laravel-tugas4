<!DOCTYPE html>
<html>
<head>
	<title>Sistem Pengolahan Data Gudang Barang</title>
</head>
<body>
 
	<h3>Edit Pegawai</h3>
 
	<a href="/persediaanbarang"> Kembali</a>
	
	<br/>
	<br/>
 
	@foreach($persediaanbarang as $p)
	<form action="/persediaanbarang/update" method="post">
		{{ csrf_field() }}
		<input type="hidden" name="id_barang" value="{{ $p->id_barang }}"> <br/>
		Kode Barang <input type="text" required="required" name="kodebarang" value="{{ $p->kodebarang }}"> <br/>
		Nama Barang <input type="text" required="required" name="namabarang" value="{{ $p->namabarang }}"> <br/>
		Harga Pokok <input type="number" required="required" name="hargapokok" value="{{ $p->hargapokok }}"> <br/>
		Harga Jual Satuan <input type="number" required="required" name="hargajualsatuan" value="{{ $p->hargajualsatuan }}"> <br/>
        Jumlah <input type="number" required="required" name="jumlah" value="{{ $p->jumlah }}"> <br/>
        Nilai <input type="number" required="required" name="nilai" value="{{ $p->nilai }}"> <br/>
		<input type="submit" value="Simpan Data">
	</form>
	@endforeach
		
 
</body>
</html>